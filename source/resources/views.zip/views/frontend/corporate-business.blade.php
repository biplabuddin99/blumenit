
 @extends('layout.frontend.front')

 @section('title', 'Home')
 
 @section('content')

  <div class="cs-slider cs-style1">
    <div class="cs-slider_container" data-autoplay="0" data-loop="1" data-speed="600" data-center="0" data-slides-per-view="1">
      <div class="cs-slider_wrapper">
          @if ($slide)
          @foreach ($slide as $item)
            <div class="cs-slide">
                <img src="{{asset($item->image)}}" alt="" class="w-100">
            </div>
          @endforeach
        @endif
      </div>
    </div>
    <div class="cs-pagination cs-style1 cs-type1"></div>
  </div>
  <div class="cs-height_60 cs-height_lg_60"></div>
  <div class="container">
    <div class="row">
      <div class="col-xl-5">
        <div class="cs-image_box_5">
          <img src="assets/img/business_img_1.jpg" alt="" class="w-100">
        </div>
        <div class="cs-height_20 cs-height_lg_20"></div>
      </div>
      <div class="col-xl-7">
        <div class="cs-text_box cs-style2">
          <h2 class="cs-text_box_title"><span>Network <span class="cs-accent_color">Solutions</span></span></h2>
          <p>Our product range includes many passive component manufacturers including brands like Belden, Legrand, 3M, commscope and many more. Our Network and technical experts provide the insight to help customers select the solutions that best meet their needs, and maximize their return on investment.</p>
        </div>
        <div class="cs-height_25 cs-height_lg_25"></div>
        <div class="cs-logos_3">
          <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/network/1.png" alt="Logo"></div>
          <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/network/2.png" alt="Logo"></div>
          <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/network/3.png" alt="Logo"></div>
        </div>
      </div>
    </div>
    <div class="cs-height_10 cs-height_lg_10"></div>
    <div class="text-center"><a href="#" class="cs-btn cs-style5 cs-type3 cs-color1">REQUEST</a></div>
  </div>
  <div class="cs-height_50 cs-height_lg_50"></div>
  <div class="container">
    <div class="cs-sectoin_wrap_2">
      <div class="row cs-col_reverse_xl">
        <div class="col-xl-7">
          <div class="cs-text_box cs-style2">
            <h2 class="cs-text_box_title"><span>Switches, <span class="cs-accent_color">Routers & Wireless</span></span></h2>
            <p>Our wide range of brands includes HPE, CISCO, Juniper, Extreme Networks, Fortinet, Mellanox, D-Link, CISCO-SMB, Avaya, TP-Link, Ubiquiti Networks and many more. We offer customers with standby switches and replacements within in no time to extend our support and service. Organization's can now access their corporate applications and data from anywhere within the organization.</p>
          </div>
          <div class="cs-height_25 cs-height_lg_25"></div>
          <div class="cs-logos_3">
            <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/switch/1.png" alt="Logo"></div>
            <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/switch/2.png" alt="Logo"></div>
            <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/switch/3.png" alt="Logo"></div>
          </div>
        </div>
        <div class="col-xl-5">
          <div class="cs-image_box_5">
            <img src="assets/img/business_img_2.jpg" alt="" class="w-100">
          </div>
          <div class="cs-height_20 cs-height_lg_20"></div>
        </div>
      </div>
      <div class="cs-logos_5">
        <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/switch/4.png" alt="Logo"></div>
        <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/switch/5.png" alt="Logo"></div>
        <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/switch/6.png" alt="Logo"></div>
        <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/switch/7.png" alt="Logo"></div>
        <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/switch/8.png" alt="Logo"></div>
      </div>
      <div class="cs-height_30 cs-height_lg_30"></div>
      <div class="text-center"><a href="#" class="cs-btn cs-style5 cs-type3 cs-color1">REQUEST</a></div>
    </div>
  </div>
  <div class="cs-height_50 cs-height_lg_50"></div>
  <div class="container">
    <div class="row">
      <div class="col-xl-5">
        <div class="cs-image_box_5">
          <img src="assets/img/business_img_3.jpg" alt="" class="w-100">
        </div>
        <div class="cs-height_20 cs-height_lg_20"></div>
      </div>
      <div class="col-xl-7">
        <div class="cs-text_box cs-style2">
          <h2 class="cs-text_box_title"><span>Computers <span class="cs-accent_color">Components</span></span></h2>
          <p>Our product range includes many passive component manufacturers including brands like Belden, Legrand, 3M, commscope and many more. Our Network and technical experts provide the insight to help customers select the solutions that best meet their needs, and maximize their return on investment.</p>
        </div>
        <div class="cs-height_25 cs-height_lg_25"></div>
        <div class="cs-logos_3">
          <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/computer/1.png" alt="Logo"></div>
          <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/computer/2.png" alt="Logo"></div>
          <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/computer/3.png" alt="Logo"></div>
        </div>
      </div>
    </div>
    <div class="cs-logos_5">
      <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/computer/4.png" alt="Logo"></div>
      <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/computer/5.png" alt="Logo"></div>
      <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/computer/6.png" alt="Logo"></div>
      <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/computer/7.png" alt="Logo"></div>
      <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/computer/8.png" alt="Logo"></div>
      <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/computer/9.png" alt="Logo"></div>
      <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/computer/10.png" alt="Logo"></div>
      <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/computer/11.png" alt="Logo"></div>
      <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/computer/12.png" alt="Logo"></div>
      <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/computer/13.png" alt="Logo"></div>
    </div>
    <div class="cs-height_30 cs-height_lg_30"></div>
    <div class="text-center"><a href="#" class="cs-btn cs-style5 cs-type3 cs-color1">REQUEST</a></div>
  </div>
  <div class="cs-height_50 cs-height_lg_50"></div>
  <div class="container">
    <div class="cs-sectoin_wrap_2">
      <div class="row cs-col_reverse_xl">
        <div class="col-xl-7">
          <div class="cs-text_box cs-style2">
            <h2 class="cs-text_box_title"><span>Gaming <span class="cs-accent_color">Computers</span></span></h2>
            <p>Our product range includes many passive component manufacturers including brands like Belden, Legrand, 3M, commscope and many more. Our Network and technical experts provide the insight to help customers select the solutions that best meet their needs, and maximize their return on investment.</p>
          </div>
          <div class="cs-height_25 cs-height_lg_25"></div>
          <div class="cs-logos_3">
            <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/gaming/1.png" alt="Logo"></div>
            <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/gaming/2.png" alt="Logo"></div>
            <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/gaming/3.png" alt="Logo"></div>
          </div>
        </div>
        <div class="col-xl-5">
          <div class="cs-image_box_5">
            <img src="assets/img/business_img_4.jpg" alt="" class="w-100">
          </div>
          <div class="cs-height_20 cs-height_lg_20"></div>
        </div>
      </div>
      <div class="cs-logos_5">
        <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/gaming/4.png" alt="Logo"></div>
        <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/gaming/5.png" alt="Logo"></div>
        <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/gaming/6.png" alt="Logo"></div>
        <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/gaming/7.png" alt="Logo"></div>
        <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/gaming/8.png" alt="Logo"></div>
      </div>
      <div class="cs-height_10 cs-height_lg_10"></div>
      <div class="text-center"><a href="#" class="cs-btn cs-style5 cs-type3 cs-color1">REQUEST</a></div>
    </div>
  </div>
  <div class="cs-height_50 cs-height_lg_50"></div>
  <div class="container">
    <div class="row">
      <div class="col-xl-5">
        <div class="cs-image_box_5">
          <img src="assets/img/business_img_5.jpg" alt="" class="w-100">
        </div>
        <div class="cs-height_20 cs-height_lg_20"></div>
      </div>
      <div class="col-xl-7">
        <div class="cs-text_box cs-style2">
          <h2 class="cs-text_box_title"><span>Laptop <span class="cs-accent_color">Computer</span></span></h2>
          <p>Our product range includes many passive component manufacturers including brands like Belden, Legrand, 3M, commscope and many more. Our Network and technical experts provide the insight to help customers select the solutions that best meet their needs, and maximize their return on investment.</p>
        </div>
        <div class="cs-height_25 cs-height_lg_25"></div>
        <div class="cs-logos_3">
          <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/laptop/1.png" alt="Logo"></div>
          <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/laptop/2.png" alt="Logo"></div>
          <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/laptop/3.png" alt="Logo"></div>
        </div>
      </div>
    </div>
    <div class="cs-logos_5">
      <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/laptop/4.png" alt="Logo"></div>
      <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/laptop/5.png" alt="Logo"></div>
      <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/laptop/6.png" alt="Logo"></div>
      <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/laptop/7.png" alt="Logo"></div>
      <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/laptop/8.png" alt="Logo"></div>
    </div>
    <div class="cs-height_30 cs-height_lg_30"></div>
    <div class="text-center"><a href="#" class="cs-btn cs-style5 cs-type3 cs-color1">REQUEST</a></div>
  </div>
  <div class="cs-height_50 cs-height_lg_50"></div>
  <div class="container">
    <div class="cs-sectoin_wrap_2">
      <div class="row cs-col_reverse_xl">
        <div class="col-xl-7">
          <div class="cs-text_box cs-style2">
            <h2 class="cs-text_box_title"><span>Servers & <span class="cs-accent_color">Storage Solutions</span></span></h2>
            <p>Blumen is one of the largest distributors in servers, supercomputing, workstations, GPU servers and storage solutions. We orrfer most reliable, high-performance, quality servers from brands like HP, DELL, IBM, Cisco and Supermicro. Our solutions are today’s standards, with tomorrow in mind, ensuring future proof high performance applications with new levels of storage performance, scalability and reliability.</p>
          </div>
          <div class="cs-height_25 cs-height_lg_25"></div>
          <div class="cs-logos_3">
            <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/server/1.png" alt="Logo"></div>
            <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/server/2.png" alt="Logo"></div>
            <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/server/3.png" alt="Logo"></div>
          </div>
        </div>
        <div class="col-xl-5">
          <div class="cs-image_box_5">
            <img src="assets/img/business_img_6.jpg" alt="" class="w-100">
          </div>
          <div class="cs-height_20 cs-height_lg_20"></div>
        </div>
      </div>
      <div class="cs-logos_5">
        <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/server/4.png" alt="Logo"></div>
        <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/server/5.png" alt="Logo"></div>
        <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/server/6.png" alt="Logo"></div>
        <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/server/7.png" alt="Logo"></div>
        <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/server/8.png" alt="Logo"></div>
      </div>
      <div class="cs-height_10 cs-height_lg_10"></div>
      <div class="text-center"><a href="#" class="cs-btn cs-style5 cs-type3 cs-color1">REQUEST</a></div>
    </div>
  </div>
  <div class="cs-height_50 cs-height_lg_50"></div>
  <div class="container">
    <div class="row">
      <div class="col-xl-5">
        <div class="cs-image_box_5">
          <img src="assets/img/business_img_7.jpg" alt="" class="w-100">
        </div>
        <div class="cs-height_20 cs-height_lg_20"></div>
      </div>
      <div class="col-xl-7">
        <div class="cs-text_box cs-style2">
          <h2 class="cs-text_box_title"><span>Printers <span class="cs-accent_color">& Supplies</span></span></h2>
          <p>Is your business in the market to replace its printers or increase its printing capabilities? We offer an extensive selection of printers and printer supplies, including Scanner and Ink-Toner. Blumen IT has a large inventory of printers from top manufacturers, including HP, Canon, Epson, Brother, Lexmark, Kyocera, Xerox, Samsung. We offers a wide selection of printers.</p>
        </div>
        <div class="cs-height_25 cs-height_lg_25"></div>
        <div class="cs-logos_3">
          <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/printer/1.png" alt="Logo"></div>
          <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/printer/2.png" alt="Logo"></div>
          <div class="cs-logo_carousel_2"><img src="assets/img/business_logo/printer/3.png" alt="Logo"></div>
        </div>
      </div>
    </div>
    <div class="cs-height_10 cs-height_lg_10"></div>
    <div class="text-center"><a href="#" class="cs-btn cs-style5 cs-type3 cs-color1">REQUEST</a></div>
  </div>
  <div class="cs-height_60 cs-height_lg_60"></div>
 @endsection